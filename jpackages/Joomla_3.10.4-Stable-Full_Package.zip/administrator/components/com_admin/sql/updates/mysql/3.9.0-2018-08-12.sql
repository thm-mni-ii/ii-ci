ALTER TABLE `#__privacy_consents` ADD COLUMN `state` INT NOT NULL DEFAULT 1 AFTER `user_id`;
